class Szerver{
    url="http://localhost:3000/api"
    getFelhasznalno_ha_az_utvonal_jo(url,id){
        if(url==`${this.url}/fiokok/${id}`){
            return {id:id,felhasznalonev:"TesztElek",email:"elek@teszt.hu",jelszo:"Jelszo12@",kituntetes:"kezdő"};
        }
        throw "Hibás útvonal";
    }

    getTortenet_ha_az_utvonal_jo(url,fiok_id,tortenet_id){
        if(url==`${this.url}/tortenetek/${fiok_id}/${tortenet_id}`){
            return {
                id: 739,
                cim: "Teszt",
                tortenet: "Ez egy teszt történet.",
                keletkezes_datum: "2026-01-21T22:55:18.000Z",
                tortenet_datum_kezdet: "2026-01-11T23:00:00.000Z",
                tortenet_datum_vege: "2026-01-14T23:00:00.000Z",
                kep_url: "",
                fiok_id: fiok_id,
                tortenet_id: tortenet_id,
                telepules_id: 739,
                telepules: "Fehérgyarmat",
                latitude: 47.9850963,
                longitude: 22.5167524,
                megye: "Szabolcs-Szatmár-Bereg"
            };
        }
        throw "Hibás útvonal";
    }
}

module.exports={Szerver};
