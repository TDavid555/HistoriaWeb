const{Szerver}=require("../szerver");
const szerver=new Szerver();
describe("Útvonal tesztek",()=>{
    const utvonal="http://localhost:3000/api";
    describe("Fiók tesztek",()=>{
        const id=1;
        const felhasznalo=szerver.getFelhasznalno_ha_az_utvonal_jo(`${utvonal}/fiokok/${id}`,id);
        test("felhasználónév egyezik az elvárttal",()=>{
            const felhasznalonev=felhasznalo.felhasznalonev;
            expect(felhasznalonev).toBe("TesztElek");
        });
        test("email egyezik az elvárttal",()=>{
            const email=felhasznalo.email;
            expect(email).toBe("elek@teszt.hu");
        });
        test("jelszó egyezik az elvárttal",()=>{
            const jelszo=felhasznalo.jelszo;
            expect(jelszo).toBe("Jelszo12@");
        });
        test("kitüntetés egyezik az elvárttal",()=>{
            const kituntetes=felhasznalo.kituntetes;
            expect(kituntetes).toBe("kezdő");
        });
    });

    describe("Történetek tesztek",()=>{
        const fiok_id=1;
        const tortenet_id=1;
        const tortenet=szerver.getTortenet_ha_az_utvonal_jo(`${utvonal}/tortenetek/${fiok_id}/${tortenet_id}`,fiok_id,tortenet_id);
        test("cím egyezik az elvárttal",()=>{
            const cim=tortenet.cim;
            expect(cim).toBe("Teszt");
        });
        test("történet egyezik az elvárttal",()=>{
            const tortenet_szoveg=tortenet.tortenet;
            expect(tortenet_szoveg).toBe("Ez egy teszt történet.");
        });
        test("keletkezes dátum egyezik az elvárttal",()=>{
            const keletkezes=tortenet.keletkezes_datum;
            expect(keletkezes).toBe("2026-01-21T22:55:18.000Z");
        });
        test("történet kezdet dátum egyezik az elvárttal",()=>{
            const kezdet=tortenet.tortenet_datum_kezdet;
            expect(kezdet).toBe("2026-01-11T23:00:00.000Z");
        });
        test("történet vége dátum egyezik az elvárttal",()=>{
            const vege=tortenet.tortenet_datum_vege;
            expect(vege).toBe("2026-01-14T23:00:00.000Z");
        });
        test("kép url egyezik az elvárttal",()=>{
            const kep_url=tortenet.kep_url;
            expect(kep_url).toBe("");
        });
        test("település egyezik az elvárttal",()=>{
            const telepules=tortenet.telepules;
            expect(telepules).toBe("Fehérgyarmat");
        });
        test("megye egyezik az elvárttal",()=>{
            const megye=tortenet.megye;
            expect(megye).toBe("Szabolcs-Szatmár-Bereg");
        });
    });
});