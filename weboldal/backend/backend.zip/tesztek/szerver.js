const express = require('express');
const cors = require("cors");
const bodyParser = require("body-parser");
const app = express();
app.use(cors());
app.use(bodyParser.json());

app.get("/api/fiokok/:id", (req, res) => {
    const id = parseInt(req.params.id);
    if (id === 1) {
        res.json({ id: 1, felhasznalonev:"TesztElek", email: 'elek@teszt.com',jelszo:"Jelszo12@" });
    } 
    else {
        res.status(404).json({ error: "Felhasználó nem található!" });
    }
});

module.exports=app;