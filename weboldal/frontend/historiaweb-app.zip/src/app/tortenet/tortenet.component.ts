import { Component, OnInit } from '@angular/core';
import { TortenetekService } from '../tortenetek.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-tortenet',
  standalone: false,
  templateUrl: './tortenet.component.html',
  styleUrls: ['./tortenet.component.css']
})
export class TortenetComponent implements OnInit {
  tortenet:any={};
  hozzaszolas:string="";
  private id=localStorage.getItem("id");
  constructor(private tortenetekService:TortenetekService,private router:ActivatedRoute){}
  ngOnInit(): void {
    if(this.id!=null){
      this.tortenetekService.getLike(parseInt(this.router.snapshot.paramMap.get("id")),parseInt(this.id)).subscribe(eredmeny=>{
        if(eredmeny.length!=0){
          document.getElementById("like").classList.add("bi-hand-thumbs-up-fill");
          document.getElementById("like").classList.remove("bi-hand-thumbs-up");
          document.getElementById("like").setAttribute("disabled","");
        }
        else{
          document.getElementById("like").classList.add("bi-hand-thumbs-up");
          document.getElementById("like").classList.remove("bi-hand-thumbs-up-fill");
          document.getElementById("like").removeAttribute("disabled");
        }
      });
    }
    else{
      document.getElementById("like").removeAttribute("disabled");
    }
    this.Tortenet();
  }

  Like():void{
    this.tortenetekService.addLike(parseInt(this.router.snapshot.paramMap.get("id")),parseInt(this.id)).subscribe(eredmeny=>{
      this.Tortenet();
      document.getElementById("like").classList.add("bi-hand-thumbs-up-fill");
      document.getElementById("like").classList.remove("bi-hand-thumbs-up");
      document.getElementById("like").setAttribute("disabled","true");
    });

  }

  Dislike():void{
    this.tortenetekService.deleteLike(parseInt(this.router.snapshot.paramMap.get("id")),parseInt(this.id)).subscribe(eredmeny=>{
      this.Tortenet();
      document.getElementById("like").classList.add("bi-hand-thumbs-up");
      document.getElementById("like").classList.remove("bi-hand-thumbs-up-fill");
      document.getElementById("like").removeAttribute("disabled");
    });
  }

  Tortenet():void{
    this.tortenetekService.getTortenetByTortenetId(parseInt(this.router.snapshot.paramMap.get("id"))).subscribe(tortenet=>{
      tortenet.tortenet_datum_kezdet=new Date(tortenet.tortenet_datum_kezdet).toLocaleDateString();
      tortenet.tortenet_datum_vege=new Date(tortenet.tortenet_datum_vege).toLocaleDateString();
      tortenet.keletkezes_datum=new Date(tortenet.keletkezes_datum).toLocaleString();
      this.tortenet=tortenet;
    });
  }

  Kuldes():void{
    this.tortenetekService.addHozzaszolas(this.hozzaszolas,parseInt(this.router.snapshot.paramMap.get("id")),parseInt(this.id)).subscribe(()=>{
      this.Tortenet();
    });
  }

  Van():boolean{
    return localStorage.getItem("id")==undefined;
  }


}
