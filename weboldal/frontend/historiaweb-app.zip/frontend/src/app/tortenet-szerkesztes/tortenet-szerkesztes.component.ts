import { Component } from '@angular/core';

@Component({
  selector: 'app-tortenet-szerkesztes',
  standalone: false,
  templateUrl: './tortenet-szerkesztes.component.html',
  styleUrl: './tortenet-szerkesztes.component.css'
})
export class TortenetSzerkesztesComponent {

}
