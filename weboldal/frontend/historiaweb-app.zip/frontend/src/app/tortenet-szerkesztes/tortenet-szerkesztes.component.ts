import { Component, OnInit } from '@angular/core';
import { TelepulesekService } from '../telepulesek.service';
import { BejelentkezesService } from '../bejelentkezes.service';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { TortenetekService } from '../tortenetek.service';

@Component({
  selector: 'app-tortenet-szerkesztes',
  standalone: false,
  templateUrl: './tortenet-szerkesztes.component.html',
  styleUrl: './tortenet-szerkesztes.component.css'
})
export class TortenetSzerkesztesComponent implements OnInit {
  tortenet:any={cim:"",tortenet:"",tortenet_datum_kezdet:"",tortenet_datum_vege:"",kep_url:"",telepulesek:[]};
  megyek:any[]=[];
  telepulesek:any[]=[];
  valasztot_megyek:string[]=[];
  private van_cim:boolean=false;
  private cim="";
  constructor(private telepulesekService:TelepulesekService,private bejelentkezesService:BejelentkezesService,private router:Router,private route:ActivatedRoute,private tortenetekService:TortenetekService){}
  
  ngOnInit(): void {
    this.telepulesekService.getMegyek().subscribe(megyek=>{
      this.megyek=megyek;
    });
    this.tortenetekService.getTortenetByTortenetId(parseInt(this.route.snapshot.paramMap.get("id"))).subscribe(tortenet=>{
      tortenet.tortenet_datum_vege=new Date(tortenet.tortenet_datum_vege).toLocaleDateString("en-CA");
      tortenet.tortenet_datum_kezdet=new Date(tortenet.tortenet_datum_kezdet).toLocaleDateString("en-CA");
      tortenet.megyek=tortenet.megyek.split(",");
      this.valasztot_megyek=tortenet.megyek;
      this.Telepulesek();
      tortenet.telepulesek=tortenet.telepulesek.split(",");
      this.tortenet=tortenet;
      this.cim=tortenet.cim;
    })
  }

  Telepulesek():void{
    this.telepulesek=[];
    this.tortenet.telepulesek=[];
    this.valasztot_megyek.forEach(megye=>{
      this.telepulesekService.getTelepulesekByMegye(megye).subscribe(telepulesek=>{
        this.telepulesek=this.telepulesek.concat(telepulesek);
      });
    });
  }

  Torles():void{
    this.tortenetekService.deleteTortenetByTortenetId(parseInt(this.route.snapshot.paramMap.get("id"))).subscribe(()=>{
      this.router.navigate(["/fiok_szerkesztes"]);
    })
  }

  Ellenorzes():void{
    if(this.tortenet.cim.trim()!=""){
      this.bejelentkezesService.getTortenetByCimFiokId(this.tortenet.cim.trim()).subscribe(tortenetek=>{
        this.van_cim=tortenetek.length!=0;
        this.Kuldes();
      });
    }
    else{
      this.Kuldes();
    }
  }

  Validalas(feltetel:boolean,id:string):void{
    if(feltetel){
      document.getElementById(id).classList.remove("is-valid");
      document.getElementById(id).classList.add("is-invalid");
    }
    else{
      document.getElementById(id).classList.remove("is-invalid");
      document.getElementById(id).classList.add("is-valid");
    }
  }

  Kuldes():void{
    let kep_pattern=/\.(gif|jpe?g|tiff?|png|webp|bmp)$/i;
    this.Validalas(this.tortenet.telepulesek.length==0,"telepules");
    this.Validalas(this.valasztot_megyek.length==0,"megye");
    this.Validalas(this.tortenet.cim.trim()=="" || (this.van_cim && this.tortenet.cim!=this.cim),"cim");
    if(this.tortenet.tortenet_datum_vege==""){
      this.tortenet.tortenet_datum_vege=new Date().toLocaleDateString("en-CA");;
    }
    if(this.tortenet.tortenet_datum_kezdet==""){
      this.tortenet.tortenet_datum_kezdet=new Date().toLocaleDateString("en-CA");;
    }
    this.Validalas(new Date(this.tortenet.tortenet_datum_vege).getTime()-new Date(this.tortenet.tortenet_datum_kezdet).getTime()<0 || Date.now()-new Date(this.tortenet.tortenet_datum_vege).getTime()<0,"tortenet_vege");
    this.Validalas(new Date(this.tortenet.tortenet_datum_vege).getTime()-new Date(this.tortenet.tortenet_datum_kezdet).getTime()<0 || new Date(this.tortenet.tortenet_datum_kezdet).getTime()==new Date().getTime(),"tortenet_kezdet");
    this.Validalas(this.tortenet.tortenet.trim()=="","tortenet");

    if(this.tortenet.telepulesek.length!=0 && this.valasztot_megyek.length!=0 && this.tortenet.cim.trim()!="" && this.tortenet.tortenet.trim()!="" && this.tortenet.tortenet_datum_kezdet!="" && this.tortenet.tortenet_datum_vege!="" && (!this.van_cim || this.tortenet.cim==this.cim) && (kep_pattern.test(this.tortenet.kep_url) || this.tortenet.kep_url.trim()=="")){
      this.tortenetekService.updateTortenetByTortenetId(this.tortenet,parseInt(this.route.snapshot.paramMap.get("id"))).subscribe(()=>{
        this.router.navigate([`/tortenetek/${this.tortenet.telepulesek[0]}/${this.tortenet.tortenet_id}`]);
      });
    }
  }
}
