import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TortenetekService {
  private api="http://localhost:3000/api";
  constructor(private http:HttpClient) { }
  getTortenetekByTelepules(telepules:string):Observable<any>{
    return this.http.get(`${this.api}/tortenet/${telepules}`);
  }
  
  getTortenetByTortenetId(id:number):Observable<any>{
    return this.http.get(`${this.api}/tortenet/telepules/${id}`);
  }

  getTortenetekOrderByLikes():Observable<any>{
    return this.http.get(`${this.api}/tortenetek/likes`);
  }

  getTortenetekOrderByDate():Observable<any>{
    return this.http.get(`${this.api}/tortenetek`);
  }

  updateTortenetByTortenetId(tortenet:any,id:number):Observable<any>{
    return this.http.put(`${this.api}/tortenetek/${id}`,tortenet);
  }

  deleteTortenetByTortenetId(id:number):Observable<any>{
    return this.http.delete(`${this.api}/tortenetek/${id}`);
  }
}
