import { Component, OnInit } from '@angular/core';
import { TortenetekService } from '../tortenetek.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-tortenet',
  standalone: false,
  templateUrl: './tortenet.component.html',
  styleUrls: ['./tortenet.component.css']
})
export class TortenetComponent implements OnInit {
  tortenet:any={};
  constructor(private tortenetekService:TortenetekService,private router:ActivatedRoute){}
  ngOnInit(): void {
    this.tortenetekService.getTortenetByTortenetId(parseInt(this.router.snapshot.paramMap.get("id"))).subscribe(tortenet=>{
      tortenet.tortenet_datum_kezdet=new Date(tortenet.tortenet_datum_kezdet).toLocaleDateString();
      tortenet.tortenet_datum_vege=new Date(tortenet.tortenet_datum_vege).toLocaleDateString();
      tortenet.keletkezes_datum=new Date(tortenet.keletkezes_datum).toLocaleString();
      this.tortenet=tortenet;
    });
  }
}
