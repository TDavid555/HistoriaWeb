import { Component, OnInit } from '@angular/core';
import { BejelentkezesService } from '../bejelentkezes.service';
import { TelepulesekService } from '../telepulesek.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tortenet-megosztas',
  standalone: false,
  templateUrl: './tortenet-megosztas.component.html',
  styleUrls: ['./tortenet-megosztas.component.css']
})
export class TortenetMegosztasComponent implements OnInit{
  tortenet:any={cim:"",tortenet:"",tortenet_datum_kezdet:"",tortenet_datum_vege:"",kep_url:"",telepulesek:[]};
  megyek:any[]=[];
  telepulesek:any[]=[];
  valasztot_megyek:string[]=[];
  private van_cim:boolean=false;
  constructor(private telepulesekService:TelepulesekService,private bejelentkezesService:BejelentkezesService,private router:Router){}
  ngOnInit(): void {
    this.telepulesekService.getMegyek().subscribe(megyek=>{
      this.megyek=megyek;
    });
  }
  
  Telepulesek():void{
    this.telepulesek=[];
    this.tortenet.telepulesek=[];
    this.valasztot_megyek.forEach(megye=>{
      this.telepulesekService.getTelepulesekByMegye(megye).subscribe(telepulesek=>{
        this.telepulesek=this.telepulesek.concat(telepulesek);
      });
    });
  }

  Ellenorzes():void{
    if(this.tortenet.cim.trim()!=""){
      this.bejelentkezesService.getTortenetByCimFiokId(this.tortenet.cim.trim()).subscribe(tortenetek=>{
        this.van_cim=tortenetek.length==0;
        this.Kuldes();
      });
    }
    else{
      this.Kuldes();
    }
  }

  Validalas(feltetel:boolean,id:string):void{
    if(feltetel){
      document.getElementById(id).classList.remove("is-valid");
      document.getElementById(id).classList.add("is-invalid");
    }
    else{
      document.getElementById(id).classList.remove("is-invalid");
      document.getElementById(id).classList.add("is-valid");
    }
  }

  Kuldes():void{
    let kep_pattern=/\.(gif|jpe?g|tiff?|png|webp|bmp)$/i
    this.Validalas(this.tortenet.telepulesek.length==0,"telepules");
    this.Validalas(this.valasztot_megyek.length==0,"megye");
    this.Validalas(this.tortenet.cim.trim()=="" || !this.van_cim,"cim");
    this.Validalas(this.tortenet.tortenet.trim()=="","tortenet");
    if(this.tortenet.tortenet_datum_vege==""){
      this.tortenet.tortenet_datum_vege=new Date().toLocaleDateString("en-CA");
    }
    if(this.tortenet.tortenet_datum_kezdet==""){
      this.tortenet.tortenet_datum_kezdet=new Date().toLocaleDateString("en-CA");
    }
    this.Validalas(new Date(this.tortenet.tortenet_datum_vege).getTime()-new Date(this.tortenet.tortenet_datum_kezdet).getTime()<0 || Date.now()-new Date(this.tortenet.tortenet_datum_vege).getTime()<0,"tortenet_vege");
    this.Validalas(new Date(this.tortenet.tortenet_datum_vege).getTime()-new Date(this.tortenet.tortenet_datum_kezdet).getTime()<0 || new Date(this.tortenet.tortenet_datum_kezdet).getTime()==new Date().getTime(),"tortenet_kezdet");
    this.Validalas(this.tortenet.tortenet.trim()=="","tortenet");
    if(this.tortenet.telepulesek.length!=0 && this.valasztot_megyek.length!=0 && this.tortenet.cim.trim()!="" && this.tortenet.tortenet.trim()!="" && this.tortenet.tortenet_datum_kezdet!="" && this.tortenet.tortenet_datum_vege.trim()!="" && this.van_cim && (kep_pattern.test(this.tortenet.kep_url) || this.tortenet.kep_url.trim()=="") ){
      this.bejelentkezesService.addTortenet(this.tortenet).subscribe(tortenet=>{
        this.router.navigate([`/tortenetek/${tortenet.telepulesek[0]}/${tortenet.id}`]);
      });
    }
  }

}