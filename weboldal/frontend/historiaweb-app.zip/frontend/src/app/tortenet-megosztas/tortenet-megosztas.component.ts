import { Component, OnInit } from '@angular/core';
import { BejelentkezesService } from '../bejelentkezes.service';
import { TelepulesekService } from '../telepulesek.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tortenet-megosztas',
  standalone: false,
  templateUrl: './tortenet-megosztas.component.html',
  styleUrls: ['./tortenet-megosztas.component.css']
})
export class TortenetMegosztasComponent implements OnInit{
  tortenet:any={cim:"",tortenet:"",tortenet_datum_kezdet:"",tortenet_datum_vege:"",kep_url:"",telepulesek:{}};
  megyek:any[]=[];
  telepulesek:any[]=[];
  megye_be:string="";
  telepules_be:string="";
  constructor(private bejelentkezesService:BejelentkezesService,private telepulesekService:TelepulesekService,private route:Router){}
  
  ngOnInit(): void {
    this.Megyek();
  }

  Megyek():void{
    this.telepulesekService.getMegyek().subscribe(megyek=>{
      this.megyek=megyek.filter(i=>i.megye.includes(this.megye_be));
      if(this.megyek.length==0){
        this.megyek.push({megye:"Nincs ilyen megye!"});
      }
      this.telepulesek=[{telepules:"Még nem választottál megyét!"}];
    });
  }

  Telepulesek():void{
    if(this.megye_be!=""){
      this.telepulesekService.getTelepulesekByMegye(this.megye_be).subscribe(telepulesek=>{
        this.telepulesek=telepulesek.filter(i=>i.telepules.includes(this.telepules_be));
        if(this.telepulesek.length==0){
          this.telepulesek.push({telepules:"Nincs ilyen település!"});
        }
      });
    }
  }

  Kuldes():void{
    if(Object.keys(this.tortenet.telepulesek).length!=0){
      for(let i in this.tortenet.telepulesek){
        this.tortenet.telepulesek[i]=Array.from(this.tortenet.telepulesek[i]);
      }
      this.bejelentkezesService.addTortenet(this.tortenet).subscribe(tortenet=>{
        this.route.navigate([`/tortenetek/:telepules/${tortenet.id}`]);
      });
    }
  }

  Valaszt_megye(megye:string):void{
    if(megye!="Nincs ilyen megye!"){
      this.megye_be=megye;
      if(!(megye in this.tortenet.telepulesek)){
        this.tortenet.telepulesek[megye]=new Set();
      }
      this.Telepulesek();
    }
  }

  Valaszt_telepules(telepules:string):void{
    if(telepules!="Nincs ilyen település!" && telepules!="Még nem választottál megyét!"){
      this.telepules_be=telepules;
      this.tortenet.telepulesek[this.megye_be].add(telepules);
    }
  }
}
