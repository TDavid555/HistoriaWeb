export default interface Tortenet{
    id:number,
    szerzo:string,
    cim:string,
    tortenet:string,
    keletkezes_datum:Date,
    tortenet_datum_kezdet:Date,
    tortenet_datum_vege:Date,
    kep_url:string,
    megyek:string,
    telepulesek:string
    likes:number,
    dislikes:number,
    hozzaszolasok:string
}