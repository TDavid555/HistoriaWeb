export default interface Pont{
    telepules:string,
    megye:string,
    latitude:number,
    longitude:number
}