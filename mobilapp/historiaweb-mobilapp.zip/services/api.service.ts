import url from "./url.json";

const API=url.url;
export default API;