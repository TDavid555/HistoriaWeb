import stilusok from '@/styles/styles';
import { useFocusEffect, useRouter } from 'expo-router';
import React from 'react';
import { ScrollView } from 'react-native';
import { Button, Card, Text } from 'react-native-paper';
import { getSelectedTortenet } from '../state/app.state';

export default function DetailsScreen() {
  const router = useRouter();
  const tortenet = getSelectedTortenet();
  useFocusEffect(
    React.useCallback(() => {
      if(tortenet==null){
        router.navigate("/(tabs)/fooldal");
      }
    }, [tortenet,router])
  );
    if (!tortenet) {
    return null; 
  }

  return (
      <ScrollView style={{...stilusok.hatter}} contentContainerStyle={{ padding: 16 }}>
        <Card style={{backgroundColor:stilusok.tortenet.backgroundColor}}>
          <Card.Title titleStyle={stilusok.cim} title={tortenet.cim} />
          <Card.Content>
            <Text style={{color:stilusok.tortenet.color}}>{tortenet.tortenet}</Text>
          </Card.Content>
          <Card.Actions>
            <Button 
              buttonColor='blue' 
              textColor='white' 
              onPress={() => router.back()}
            >
              Vissza
            </Button>
          </Card.Actions>
        </Card>
      </ScrollView>
  );
}